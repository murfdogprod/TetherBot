import discord
from discord.ext import commands
import requests
import os
from shared import conn

c = conn.cursor()

class LovenseCog(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    # ---------------- Slash Command: Buzz ----------------
    @commands.slash_command(name="buzz", description="Send a Lovense vibration command to a user")
    async def buzz_slash(self, ctx, user: discord.Member, strength: int = 3):
        await self._buzz(ctx, user, strength)

    # ---------------- Prefix Command: !>buzz ----------------
    @commands.command(name="buzz")
    async def buzz_prefix(self, ctx, user: discord.Member, strength: int = 3):
        await self._buzz(ctx, user, strength)

    # ---------------- Core Buzz Logic ----------------
    async def _buzz(self, ctx, user: discord.Member, strength: int):
        if strength < 1 or strength > 5:
            if hasattr(ctx, "respond"):
                await ctx.respond("❌ Strength must be between 1 and 5.", ephemeral=True)
            else:
                await ctx.send("❌ Strength must be between 1 and 5.")
            return

        c.execute("SELECT token FROM lovense_users WHERE user_id = ?", (user.id,))
        row = c.fetchone()
        if not row:
            if hasattr(ctx, "respond"):
                await ctx.respond("❌ That user has not linked a Lovense toy.", ephemeral=True)
            else:
                await ctx.send("❌ That user has not linked a Lovense toy.")
            return

        target_token = row[0]
        payload = {
            "token": target_token,
            "command": f"Vibrate:{strength}"
        }

        try:
            response = requests.post("https://c.lovense.com/api/command", json=payload, timeout=5)
            result = response.json()
            if result.get("status") == "success":
                if hasattr(ctx, "respond"):
                    await ctx.respond(f"✅ Sent vibration to {user.mention} at strength {strength}.")
                else:
                    await ctx.send(f"✅ Sent vibration to {user.mention} at strength {strength}.")
            else:
                error_msg = result.get('error', 'Unknown error')
                if hasattr(ctx, "respond"):
                    await ctx.respond(f"❌ Lovense API error: {error_msg}")
                else:
                    await ctx.send(f"❌ Lovense API error: {error_msg}")
        except requests.RequestException as e:
            if hasattr(ctx, "respond"):
                await ctx.respond(f"❌ Failed to reach Lovense API: {e}")
            else:
                await ctx.send(f"❌ Failed to reach Lovense API: {e}")

    # ---------------- Slash Command: Register Token ----------------
    @commands.slash_command(name="lovense_register", description="Register your Lovense token")
    async def lovense_register_slash(self, ctx, token: str):
        c.execute("INSERT OR REPLACE INTO lovense_users (user_id, token) VALUES (?, ?)", (ctx.author.id, token))
        conn.commit()
        await ctx.respond("✅ Your Lovense token has been registered.", ephemeral=True)

    # ---------------- Prefix Command: !>lovense_register ----------------
    @commands.command(name="lovense_register")
    async def lovense_register_prefix(self, ctx, token: str):
        c.execute("INSERT OR REPLACE INTO lovense_users (user_id, token) VALUES (?, ?)", (ctx.author.id, token))
        conn.commit()
        await ctx.send("✅ Your Lovense token has been registered.")


def setup(bot):
    bot.add_cog(LovenseCog(bot))
