import discord
from discord.ext import commands
from shared import gagged_users, AUTHORIZED_LOCK_MANAGERS, check_auth, conn


c = None  # local DB cursor

class GagCog(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        global c
        if conn:
            c = conn.cursor()

    @commands.command()
    async def gag1(self, ctx, user: discord.Member = None, gag_type: str = "loose"):
        """Apply a gag type to yourself or another user"""

        valid_gags = ["loose", "medium", "harsh", "puppy", "kitty", "toy", "base64", "zalgo", "piglatin", "ungag"]
        target = user or ctx.author

        if target.id in gagged_users and ctx.author.id not in AUTHORIZED_LOCK_MANAGERS:
            await ctx.send("❌ The target is currently locked and cannot be gagged.")
            return

        if target.bot:
            await ctx.message.add_reaction("❌")
            return

        if gag_type.lower() not in valid_gags:
            await ctx.send(f"❌ Invalid gag type. Valid types: `{', '.join(valid_gags)}`")
            return

        if not await check_auth(ctx, target):
            await ctx.message.add_reaction("❌")
            return

        user_id = target.id

        if gag_type.lower() == "ungag":
            c.execute("UPDATE gagged_users SET status = 'inactive' WHERE user_id = ?", (user_id,))
            gagged_users.pop(user_id, None)
            await ctx.message.add_reaction("🗣️")
        else:
            c.execute("""
                INSERT INTO gagged_users (user_id, type, status)
                VALUES (?, ?, 'active')
                ON CONFLICT(user_id) DO UPDATE SET type=excluded.type, status='active'
            """, (user_id, gag_type))
            gagged_users[user_id] = gag_type
            await ctx.message.add_reaction("<:emoji:1367662060862705734>")

        conn.commit()

    @commands.command()
    async def ungag1(self, ctx, user: discord.Member = None):
        """Remove a user's gag status (set it to inactive)"""
        target = user or ctx.author

        if target.id in gagged_users and ctx.author.id not in AUTHORIZED_LOCK_MANAGERS:
            await ctx.send("❌ The target is currently locked and cannot be ungagged.")
            return

        if not await check_auth(ctx, target):
            await ctx.message.add_reaction("❌")
            return

        user_id = target.id
        c.execute("SELECT type FROM gagged_users WHERE user_id = ? AND status = 'active'", (user_id,))
        row = c.fetchone()

        if row:
            c.execute("UPDATE gagged_users SET status = 'inactive' WHERE user_id = ?", (user_id,))
            gagged_users.pop(user_id, None)
            conn.commit()
            await ctx.message.add_reaction("🗣️")
        else:
            await ctx.message.add_reaction("❌")


def setup(bot):
    bot.add_cog(GagCog(bot))
