import discord
from discord.ext import commands
import requests
import os
from datetime import datetime, timedelta
from shared import conn, cog_enabled, with_config_cog
from muzzled import Lovense_Token, Lovense_Key, Lovense_IV

class LovenseCog(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        self.token = Lovense_Token
        self.base_url = "https://api.lovense.com/api/lan"
        self.command_url = "https://c.lovense.com/api/command"

    async def _respond(self, ctx, message: str, ephemeral: bool = True):
        """Universal response handler for slash/prefix commands."""
        if hasattr(ctx, "respond"):
            await ctx.respond(message, ephemeral=ephemeral)
        else:
            await ctx.send(message)

    def _get_connection_link(self):
        """Generate a connection link using the stored token"""
        return f"https://api.lovense-api.com/?token={self.token}"

    def _check_toy_connected(self, token: str) -> bool:
        """Verify if the user's toy is currently connected."""
        try:
            response = requests.post(
                f"{self.base_url}/getToys",
                json={"token": token},
                timeout=3
            )
            return bool(response.json().get("toys", []))
        except requests.RequestException:
            return False

    # -------------------- Commands --------------------
    @commands.slash_command(name="buzz", description="Vibrate a user's Lovense toy")
    @cog_enabled("lovense_enabled")
    @with_config_cog
    @commands.cooldown(1, 5, commands.BucketType.user)
    async def buzz_slash(self, ctx, user: discord.Member, strength: int = 3):
        """Slash command version of buzz"""
        await self._handle_buzz(ctx, user, strength)

    @commands.command(name="buzz")
    @cog_enabled("lovense_enabled")
    @with_config_cog
    @commands.cooldown(1, 5, commands.BucketType.user)
    async def buzz_prefix(self, ctx, user: discord.Member, strength: int = 3):
        """Prefix command version of buzz"""
        await self._handle_buzz(ctx, user, strength)

    async def _handle_buzz(self, ctx, user: discord.Member, strength: int):
        if strength < 1 or strength > 5:
            return await self._respond(ctx, "❌ Strength must be between 1-5.")

        c = ctx.server_db.cursor()
        c.execute("SELECT token FROM lovense_users WHERE user_id = ?", (user.id,))
        if not (row := c.fetchone()):
            return await self._respond(ctx, "❌ User hasn't linked a Lovense toy.")

        target_token = row[0]
        if not self._check_toy_connected(target_token):
            return await self._respond(ctx, "❌ Toy is offline. Reconnect with /lovense_link.")

        try:
            response = requests.post(
                self.command_url,
                json={
                    "token": target_token,
                    "command": f"Vibrate:{strength}",
                    "timeSec": 3
                },
                timeout=5
            )
            response.raise_for_status()
            await self._respond(ctx, f"✅ Vibrating {user.mention}'s toy at strength {strength}!")
        except requests.HTTPError as e:
            await self._respond(ctx, f"❌ API Error: {e.response.text}")
        except requests.RequestException as e:
            await self._respond(ctx, f"❌ Network Error: {str(e)}")

    @commands.slash_command(name="lovense_register", description="Link your Lovense token")
    @cog_enabled("lovense_enabled")
    @with_config_cog
    async def register_slash(self, ctx, token: str):
        """Slash command to register token"""
        await self._register_token(ctx, token)

    @commands.command(name="lovense_register")
    @cog_enabled("lovense_enabled")
    @with_config_cog
    async def register_prefix(self, ctx, token: str):
        """Prefix command to register token"""
        await self._register_token(ctx, token)

    async def _register_token(self, ctx, token: str):
        c = ctx.server_db.cursor()
        c.execute(
            "INSERT OR REPLACE INTO lovense_users (user_id, token) VALUES (?, ?)",
            (ctx.author.id, token)
        )
        c.connection.commit()
        await self._respond(ctx, "✅ Token registered successfully!")

    @commands.slash_command(name="lovense_link", description="Get connection link")
    @cog_enabled("lovense_enabled")
    @with_config_cog
    async def link_slash(self, ctx):
        """Slash command to get connection link"""
        await self._send_link(ctx)

    @commands.command(name="lovense_link")
    @cog_enabled("lovense_enabled")
    @with_config_cog
    async def link_prefix(self, ctx):
        """Prefix command to get connection link"""
        await self._send_link(ctx)

    async def _send_link(self, ctx):
        link = self._get_connection_link()
        await self._respond(
            ctx,
            f"🔗 Connect your toy:\n{link}\n"
            "1. Open this link on your phone\n"
            "2. Open the Lovense Remote App\n"
            "3. Tap 'Partner Link' in the app",
            ephemeral=True
        )

def setup(bot):
    bot.add_cog(LovenseCog(bot))
