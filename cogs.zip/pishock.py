import discord
from discord.ext import commands
import requests
from shared import conn, check_auth, pishock_command
import shared
from muzzled import PISHOCK_USERNAME, PISHOCK_API_KEY
from shared import cog_enabled, with_config, unpack_config, with_config_cog, safe_send, silent_executions
from discord.commands import slash_command, Option
import asyncio

c = conn.cursor()

class PiShockCog(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        shared.pishock_command = self.send_pishock_command

    def cog_unload(self):
        shared.pishock_command = None

    async def _handle_pishock_setup(self, ctx):
        """Shared logic for both prefix and slash versions"""
        is_slash = isinstance(ctx, discord.ApplicationContext)
        author = ctx.author
        guild = ctx.guild
        guild_id = guild.id
        author_id = author.id
        c = ctx.server_db.cursor()

        def check_dm(m):
            return m.author.id == author_id and isinstance(m.channel, discord.DMChannel)

        try:
            dm_channel = await author.create_dm()

            # Check existing configuration
            c.execute("SELECT code FROM pishock_users WHERE user_id = ?", (author_id,))
            existing = c.fetchone()

            if existing:
                await dm_channel.send(
                    "🛠 You already have a PiShock code registered.\n"
                    "Reply with:\n"
                    "`code` — to update code\n"
                    "`settings` — to update settings\n"
                    "`cancel` — to cancel."
                )
                try:
                    reply = await self.bot.wait_for("message", check=check_dm, timeout=60)
                except asyncio.TimeoutError:
                    return await dm_channel.send("⌛ Timed out. Please run the command again.")
                
                decision = reply.content.lower().strip()
                if decision == "cancel":
                    return await dm_channel.send("❌ Cancelled.")
                elif decision == "code":
                    await dm_channel.send("🔁 Send new PiShock code:")
                    reply = await self.bot.wait_for("message", check=check_dm, timeout=60)
                    new_code = reply.content.strip()
                    shared.user_pishock_codes[guild_id][author_id] = new_code
                    c.execute("UPDATE pishock_users SET code = ? WHERE user_id = ?", (new_code, author_id))
                    ctx.server_db.commit()
                    return await dm_channel.send("✅ Code updated.")
                elif decision != "settings":
                    return await dm_channel.send("❌ Invalid option.")

            # New setup
            await dm_channel.send("📩 Send your PiShock friend code:")
            reply = await self.bot.wait_for("message", check=check_dm, timeout=60)
            code = reply.content.strip()
            shared.user_pishock_codes[guild_id][author_id] = code
            
            # Insert new record
            c.execute("INSERT OR REPLACE INTO pishock_users (user_id, code) VALUES (?, ?)", (author_id, code))
            ctx.server_db.commit()
            await dm_channel.send("✅ Code saved.")

            # Settings setup
            await dm_channel.send("🛠 Setting up your PiShock preferences.")
            questions = [
                ("shock_min", "Minimum shock intensity (1–100):", 1, 100),
                ("shock_max", "Maximum shock intensity (1–100):", 1, 100),
                ("vibrate_min", "Minimum vibrate intensity (1–100):", 1, 100),
                ("vibrate_max", "Maximum vibrate intensity (1–100):", 1, 100),
                ("duration_min", "Minimum duration (1–15s):", 1, 15),
                ("duration_max", "Maximum duration (1–15s):", 1, 15),
                ("line_writing_shock_intensity", "Line writing intensity (0–100):", 0, 100),
                ("line_writing_shock_duration", "Line writing duration (1–15):", 1, 15),
                ("enforcement_action_shock_intensity", "Enforcement intensity (0–100):", 0, 100),
                ("enforcement_action_shock_duration", "Enforcement duration (1–15):", 1, 15),
                ("lightning_reaction_shock_intensity", "Lightning reaction intensity (0–100):", 0, 100),
                ("lightning_reaction_shock_duration", "Lightning reaction duration (1–15):", 1, 15),
            ]

            responses = {}
            for key, prompt, min_v, max_v in questions:
                while True:
                    try:
                        await dm_channel.send(prompt)
                        msg = await self.bot.wait_for("message", check=check_dm, timeout=90)
                        value = int(msg.content.strip())
                        if min_v <= value <= max_v:
                            responses[key] = value
                            break
                        else:
                            await dm_channel.send(f"❌ Value must be {min_v}-{max_v}.")
                    except ValueError:
                        await dm_channel.send("❌ Invalid number.")
                    except asyncio.TimeoutError:
                        return await dm_channel.send("⌛ Timed out.")

            # Ensure min/max consistency
            for min_key, max_key in [("shock_min", "shock_max"), ("vibrate_min", "vibrate_max"), ("duration_min", "duration_max")]:
                if responses[min_key] > responses[max_key]:
                    responses[max_key] = responses[min_key]

            # Update settings
            update_query = """
                UPDATE pishock_users SET
                    shock_min = ?, shock_max = ?,
                    vibrate_min = ?, vibrate_max = ?,
                    duration_min = ?, duration_max = ?,
                    line_writing_shock_intensity = ?, line_writing_shock_duration = ?,
                    enforcement_action_shock_intensity = ?, enforcement_action_shock_duration = ?,
                    lightning_reaction_shock_intensity = ?, lightning_reaction_shock_duration = ?
                WHERE user_id = ?
            """
            update_values = [responses[k] for k, *_ in questions] + [author_id]
            c.execute(update_query, update_values)
            ctx.server_db.commit()

            await dm_channel.send("✅ Settings saved.")

        except discord.Forbidden:
            response = "❌ I couldn't DM you. Please enable DMs."
            if is_slash:
                await ctx.respond(response, ephemeral=True)
            else:
                await ctx.send(response)

    # Prefix command
    @commands.command(name="pishock")
    @cog_enabled("pishock_enabled")
    @with_config_cog
    async def pishock_prefix(self, ctx):
        await self._handle_pishock_setup(ctx)

    # Slash command
    @slash_command(name="pishock", description="Set or update your PiShock code and preferences.")
    @cog_enabled("pishock_enabled")
    @with_config_cog
    async def pishock_slash(self, ctx: discord.ApplicationContext):
        await ctx.defer(ephemeral=True)
        await self._handle_pishock_setup(ctx)

    @commands.command(name='pishock_users', aliases=['shockers', 'shock_users'])
    @cog_enabled("pishock_enabled")
    @with_config_cog
    async def pishock_users(self, ctx):
        c = ctx.server_db.cursor()
        c.execute("SELECT user_id FROM pishock_users")
        results = c.fetchall()

        if not results:
            await ctx.send("⚠️ No users have registered a PiShock code yet.")
            return

        visible_users = []
        for (user_id,) in results:
            member = ctx.guild.get_member(user_id)
            if member:
                visible_users.append(member.mention)

        if not visible_users:
            await ctx.send("⚠️ No PiShock users found in this server.")
            return

        embed = discord.Embed(
            title="⚡ Registered PiShock Users",
            description="\n".join(visible_users),
            color=0xff5733
        )
        await ctx.send(embed=embed)

    @slash_command(name="pishock_users", description="List PiShock users in this server")
    @cog_enabled("pishock_enabled")
    @with_config_cog
    async def pishock_users_slash(self, ctx):
        c = ctx.server_db.cursor()
        c.execute("SELECT user_id FROM pishock_users")
        results = c.fetchall()

        if not results:
            await ctx.respond("⚠️ No registered PiShock users", ephemeral=True)
            return

        visible_users = []
        for (user_id,) in results:
            member = ctx.guild.get_member(user_id)
            if member:
                visible_users.append(member.mention)

        if not visible_users:
            await ctx.respond("⚠️ No PiShock users found", ephemeral=True)
            return

        embed = discord.Embed(
            title="⚡ Registered PiShock Users",
            description="\n".join(visible_users),
            color=0xff5733
        )
        await ctx.respond(embed=embed, ephemeral=True)

    @commands.command(name='removepishock', aliases=['deletepishock', 'unpishock'])
    @cog_enabled("pishock_enabled")
    @with_config_cog
    async def removepishock(self, ctx):
        c = ctx.server_db.cursor()
        guild_id = ctx.guild.id
        user_id = ctx.author.id

        c.execute("DELETE FROM pishock_users WHERE user_id = ?", (user_id,))
        ctx.server_db.commit()

        if guild_id in shared.user_pishock_codes and user_id in shared.user_pishock_codes[guild_id]:
            del shared.user_pishock_codes[guild_id][user_id]

        await ctx.send("🗑️ Your PiShock configuration has been removed.")

    def send_pishock_command(self, guild_id: int, user_id: int, op: int, intensity: int, duration: int = 3):
        if not shared.is_cog_enabled(guild_id, "pishock_enabled"):
            return {"Success": False, "Message": "PiShock is disabled for this server."}

        if guild_id not in shared.user_pishock_codes or user_id not in shared.user_pishock_codes[guild_id]:
            return {"Success": False, "Message": "User has no PiShock code."}

        share_code = shared.user_pishock_codes[guild_id][user_id]

        try:
            response = requests.post(
                "https://do.pishock.com/api/apioperate/",
                json={
                    "Username": PISHOCK_USERNAME,
                    "Apikey": PISHOCK_API_KEY,
                    "Code": share_code,
                    "Name": "TetherBot",
                    "Op": op,
                    "Duration": duration,
                    "Intensity": intensity
                },
                timeout=5
            )
            if response.status_code != 200:
                return {"Success": False, "Message": f"HTTP Error: {response.status_code}"}

            return {"Success": True, "Message": response.text.strip()}
        except Exception as e:
            return {"Success": False, "Message": f"Error: {str(e)}"}

    @commands.command(name='shock')
    @cog_enabled("pishock_enabled")
    @with_config_cog
    async def shock(self, ctx, user: discord.Member, intensity: int, duration: int = 2):
        if not await check_auth(ctx, user):
            await ctx.message.add_reaction("❌")
            return

        c = ctx.server_db.cursor()
        c.execute("SELECT shock_min, shock_max, duration_min, duration_max FROM pishock_users WHERE user_id = ?", (user.id,))
        row = c.fetchone()

        if not row:
            return await ctx.send("⚠️ User has no PiShock settings.")

        shock_min, shock_max, duration_min, duration_max = row

        if not (shock_min <= intensity <= shock_max):
            return await ctx.send(f"❌ Intensity must be {shock_min}-{shock_max}%")
        if not (duration_min <= duration <= duration_max):
            return await ctx.send(f"⏱️ Duration must be {duration_min}-{duration_max}s")

        result = self.send_pishock_command(ctx.guild.id, user.id, 0, intensity, duration)
        if result["Success"]:
            await ctx.send(f"⚡ Shocked {user.display_name} at {intensity}% for {duration}s!")
        else:
            await ctx.send(f"❌ Failed: {result['Message']}")

    @slash_command(name="shock", description="Deliver a shock")
    @cog_enabled("pishock_enabled")
    @with_config_cog
    async def shock_slash(
        self,
        ctx: discord.ApplicationContext,
        user: Option(discord.Member, "User to shock"),
        intensity: Option(int, "Shock intensity (1-100)"),
        duration: Option(int, "Duration in seconds (1-15)", default=2)
    ):
        await ctx.defer()
        if not await check_auth(ctx, user):
            return await ctx.respond("❌ Not authorized", ephemeral=True)

        # Same validation as prefix command
        c = ctx.server_db.cursor()
        c.execute("SELECT shock_min, shock_max, duration_min, duration_max FROM pishock_users WHERE user_id = ?", (user.id,))
        row = c.fetchone()

        if not row:
            return await ctx.respond("⚠️ User has no PiShock settings.", ephemeral=True)

        shock_min, shock_max, duration_min, duration_max = row

        if not (shock_min <= intensity <= shock_max):
            return await ctx.respond(f"❌ Intensity must be {shock_min}-{shock_max}%", ephemeral=True)
        if not (duration_min <= duration <= duration_max):
            return await ctx.respond(f"⏱️ Duration must be {duration_min}-{duration_max}s", ephemeral=True)

        result = self.send_pishock_command(ctx.guild.id, user.id, 0, intensity, duration)
        if result["Success"]:
            await ctx.respond(f"⚡ Shocked {user.mention} at {intensity}% for {duration}s!")
        else:
            await ctx.respond(f"❌ Failed: {result['Message']}", ephemeral=True)

    @commands.command(name='vibrate')
    @cog_enabled("pishock_enabled")
    @with_config_cog
    async def vibrate(self, ctx, user: discord.Member, intensity: int, duration: int = 2):
        if not await check_auth(ctx, user):
            await ctx.message.add_reaction("❌")
            return

        c = ctx.server_db.cursor()
        c.execute("SELECT vibrate_min, vibrate_max, duration_min, duration_max FROM pishock_users WHERE user_id = ?", (user.id,))
        row = c.fetchone()

        if not row:
            return await ctx.send("⚠️ User has no PiShock settings.")

        vibrate_min, vibrate_max, dur_min, dur_max = row

        if not (vibrate_min <= intensity <= vibrate_max):
            return await ctx.send(f"❌ Intensity must be {vibrate_min}-{vibrate_max}%")
        if not (dur_min <= duration <= dur_max):
            return await ctx.send(f"⏱️ Duration must be {dur_min}-{dur_max}s")

        result = self.send_pishock_command(ctx.guild.id, user.id, 1, intensity, duration)
        if result["Success"]:
            await ctx.send(f"🔋 Vibrated {user.display_name} at {intensity}% for {duration}s!")
        else:
            await ctx.send(f"❌ Failed: {result['Message']}")

    @commands.command(name='beep')
    @cog_enabled("pishock_enabled")
    @with_config_cog
    async def beep(self, ctx, user: discord.Member, duration: int):
        if not await check_auth(ctx, user):
            await ctx.message.add_reaction("❌")
            return

        if not 1 <= duration <= 15:
            return await ctx.send("❌ Duration must be 1-15 seconds")

        result = self.send_pishock_command(ctx.guild.id, user.id, 2, 1, duration)
        if result["Success"]:
            await ctx.send(f"🔔 Beeped {user.display_name} for {duration}s!")
        else:
            await ctx.send(f"❌ Failed: {result['Message']}")

def setup(bot):
    bot.add_cog(PiShockCog(bot))