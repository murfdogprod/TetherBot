import discord
from discord.ext import commands
from discord.commands import slash_command, Option
import shared
import random
import base64
import re
import asyncio
import pronouncing
from shared import gagged_users, AUTHORIZED_LOCK_MANAGERS, check_auth, conn, gagged_messages, cog_enabled, with_config, unpack_config
c = None  # local DB cursor

class GagCog(commands.Cog):
    def __init__(self, bot):


        self.bot = bot
        global c
        if conn:
            c = conn.cursor()

        shared.handle_gagged_message = self.handle_gagged_message
        shared.enforcement_gag_send = self.gag_and_send
        shared.handle_gag_reaction = self.handle_gag_reaction



        shared.gag_functions.update({
            "loose": loose,
            "medium": medium,
            "harsh": harsh,
            "puppy": puppy,
            "kitty": kitty,
            "toy": toy,
            "base64": gag_base64,
            "zalgo": zalgo,
            "piglatin": piglatin
        })

    def cog_unload(self):


        shared.handle_gagged_message = None
        shared.enforcement_gag_send = None
        shared.handle_gag_reaction = None
        shared.gag_functions = {}

    async def handle_gag_reaction(self, reaction, user):


        message = reaction.message
        guild = message.guild
        if not guild:
            return

        # ✅ Respect cog enable/disable toggle
        if not shared.is_cog_enabled(guild.id, "gags_enabled"):
            return

        msg_id = message.id
        if msg_id not in shared.gagged_messages.get(guild.id, {}):
            return

        try:
            users = await reaction.users().flatten()

            # Ignore if only the bot reacted
            if self.bot.user in users and len(users) == 1:
                return

            # Unpack gagged message details
            author_id, original_content, webhook_id, webhook_token = shared.gagged_messages[guild.id][msg_id]
            author = guild.get_member(author_id)
            emoji = str(reaction.emoji)

            parent_channel = message.channel.parent if isinstance(message.channel, discord.Thread) else message.channel
            thread = message.channel if isinstance(message.channel, discord.Thread) else None

            webhooks = await parent_channel.webhooks()
            webhook = next((w for w in webhooks if w.id == webhook_id), None)

            # 💣 Delete
            if emoji == "💣":
                if author_id == user.id or user.id in shared.AUTHORIZED_LOCK_MANAGERS or message.channel.permissions_for(user).manage_messages:
                    await message.delete()
                    del shared.gagged_messages[guild.id][msg_id]

            # 👁️ Reveal
            elif emoji == "👁️" and webhook:
                gag_type = shared.gagged_users.get(author_id, "loose")
                color = gag_colors.get(gag_type, discord.Color.default())
                embed = discord.Embed(description=original_content, color=color)
                embed.set_author(name=f"Message from {author.display_name}", icon_url=author.display_avatar.url)

                if thread:
                    await webhook.edit_message(msg_id, embed=embed, thread=thread)
                else:
                    await webhook.edit_message(msg_id, embed=embed)

                await message.clear_reactions()
                await message.add_reaction("💣")
                await message.add_reaction("⬆️")

            # ⬆️ Hide
            elif emoji == "⬆️" and webhook:
                if thread:
                    await webhook.edit_message(msg_id, embed=None, thread=thread)
                else:
                    await webhook.edit_message(msg_id, embed=None)

                await message.clear_reactions()
                await message.add_reaction("💣")
                await message.add_reaction("👁️")

        except Exception as e:
            print(f"[GagCog] Reaction handling failed:")
            import traceback
            traceback.print_exc()

    
    async def gag_and_send(self, message, gag_type: str = "loose"):
        if not message.guild:
            return

        guild_id = message.guild.id
        if not shared.is_cog_enabled(guild_id, "gags_enabled"):
            return

        if shared.returnvar:
            return

        gag_func = shared.gag_functions.get(gag_type)
        gagged_text = gag_func(message.content) if gag_func else "[🤐 gagged]"


        parent_channel = (
            message.channel.parent if isinstance(message.channel, discord.Thread) else message.channel
        )
        webhooks = await parent_channel.webhooks()
        webhook = next((w for w in webhooks if w.user == self.bot.user), None)
        if not webhook:
            webhook = await parent_channel.create_webhook(name="GagWebhook")

        send_args = {
            "content": gagged_text,
            "username": message.author.display_name,
            "avatar_url": message.author.display_avatar.url,
            "wait": True,
        }
        if isinstance(message.channel, discord.Thread):
            send_args["thread"] = message.channel

        gag_msg = await webhook.send(**send_args)
        msg_obj = await message.channel.fetch_message(gag_msg.id)

        # ✅ Store gagged message in per-guild memory
        if guild_id not in shared.gagged_messages:
            shared.gagged_messages[guild_id] = {}

        shared.gagged_messages[guild_id][msg_obj.id] = (
            message.author.id,
            message.content,
            webhook.id,
            webhook.token
        )

        await msg_obj.add_reaction("💣")
        await msg_obj.add_reaction("👁️")

        # Start a 5-minute cleanup task for this message
        async def cleanup_gagged_message(message_obj):
            await asyncio.sleep(300)  # 5 minutes
            try:
                await message_obj.clear_reactions()
            except (discord.NotFound, discord.Forbidden):
                pass
            shared.gagged_messages[guild_id].pop(message_obj.id, None)

        self.bot.loop.create_task(cleanup_gagged_message(msg_obj))





    @commands.command()
    async def gag(self, ctx, user: discord.Member = None, gag_type = "loose"):
        # Check if the cog is enabled for this guild
        if not shared.is_cog_enabled(ctx.guild.id, "gags_enabled"):
            return

        # Apply config manually
        await ctx.defer()
        await with_config(self._gag)(ctx, user, gag_type)



    @slash_command(name="gag", description="Apply a gag type to yourself or another user")
    async def gag_slash(
        self,
        ctx,
        user: Option(discord.Member, "Select a user", required=False) = None,
        gag_type: Option(str, "Type of gag", required=False, default="loose") = "loose"
    ):
        if not shared.is_cog_enabled(ctx.guild.id, "gags_enabled"):
            return
        
        await ctx.defer()
        await with_config(self._gag)(ctx, user, gag_type)



    @slash_command(name="ungag", description="Remove a user's gag status")
    async def ungag_slash(
        self,
        ctx,
        user: Option(discord.Member, "User to ungag", required=False) = None
    ):
        if not shared.is_cog_enabled(ctx.guild.id, "gags_enabled"):
            return

        await with_config(self._ungag)(ctx, user)

    
    async def _gag(self, ctx, user: discord.Member, gag_type: str):
        guild_id = ctx.guild.id
        config = unpack_config(ctx)
        c = ctx.server_db.cursor()
        valid_gags = ["loose", "medium", "harsh", "puppy", "kitty", "toy", "base64", "zalgo", "piglatin", "ungag"]
        target = user or ctx.author


        if target.id in shared.locked_users[ctx.guild.id] and ctx.author.id not in AUTHORIZED_LOCK_MANAGERS:
            await safe_send(ctx, "❌ The target is currently locked and cannot be gagged.")
            return

        if target.bot:
            await safe_send(ctx, "❌ Cannot gag a bot.")
            return

        if gag_type.lower() not in valid_gags:
            await safe_send(ctx, f"❌ Invalid gag type. Valid types: `{', '.join(valid_gags)}`")
            return

        if not await check_auth(ctx, target):
            await safe_send(ctx, "❌ You do not have permission to gag this user.")
            return

        user_id = target.id

        if gag_type.lower() == "ungag":
            c.execute("UPDATE gagged_users SET status = 'inactive' WHERE user_id = ?", (user_id,))
            shared.gagged_users[ctx.guild.id].pop(user_id, None)
            await safe_send(ctx, "🗣️ User has been ungagged.")
        else:
            c.execute("""
                INSERT INTO gagged_users (user_id, type, status)
                VALUES (?, ?, 'active')
                ON CONFLICT(user_id) DO UPDATE SET type=excluded.type, status='active'
            """, (user_id, gag_type))
            shared.gagged_users[ctx.guild.id][user_id] = gag_type
            await safe_send(ctx, f"🔇 {target.mention} has been gagged with `{gag_type}`.")

        ctx.server_db.commit()

    @commands.command()
    async def ungag(self, ctx, user: discord.Member = None):
        # Check if the cog is enabled for this guild
        if not shared.is_cog_enabled(ctx.guild.id, "gags_enabled"):
            return

        # Apply config manually
        await with_config(self._ungag)(ctx, user)


    
    async def _ungag(self, ctx, user: discord.Member):
        guild_id = ctx.guild.id
        config = unpack_config(ctx)
        c = ctx.server_db.cursor()

        target = user or ctx.author

        if target.id in shared.locked_users[ctx.guild.id] and ctx.author.id not in AUTHORIZED_LOCK_MANAGERS:
            await safe_send(ctx, "❌ The target is currently locked and cannot be ungagged.")
            return

        if not await check_auth(ctx, target):
            await safe_send(ctx, "❌ You do not have permission to ungag this user.")
            return

        user_id = target.id
        c.execute("SELECT type FROM gagged_users WHERE user_id = ? AND status = 'active'", (user_id,))
        row = c.fetchone()

        if row:
            c.execute("UPDATE gagged_users SET status = 'inactive' WHERE user_id = ?", (user_id,))
            shared.gagged_users[guild_id].pop(user_id, None)
            ctx.server_db.commit()
            await safe_send(ctx, "🗣️ User has been ungagged.")
        else:
            await safe_send(ctx, "❌ That user is not currently gagged.")

    async def handle_gagged_message(self, message):

        if not message.guild:
            return
        if not shared.is_cog_enabled(message.guild.id, "gags_enabled"):
            return
        if shared.returnvar == True:
            return
        user_id = message.author.id
        gag_type = shared.gagged_users[message.guild.id][user_id]

        try:
            await message.delete()

            gag_func = gag_functions.get(gag_type)
            gagged_text = gag_func(message.content) if gag_func else "🤐 [Unknown gag style]"

            if isinstance(message.channel, discord.Thread):
                parent_channel = message.channel.parent
            else:
                parent_channel = message.channel

            webhooks = await parent_channel.webhooks()
            webhook = next((w for w in webhooks if w.user == self.bot.user), None)
            if not webhook:
                webhook = await parent_channel.create_webhook(name="GagWebhook")

            send_args = {
                "content": gagged_text,
                "username": message.author.display_name,
                "avatar_url": message.author.display_avatar.url,
                "wait": True
            }
            if isinstance(message.channel, discord.Thread):
                send_args["thread"] = message.channel

            gag_msg = await webhook.send(**send_args)
            msg_obj = await message.channel.fetch_message(gag_msg.id)
            gagged_messages[msg_obj.id] = (user_id, message.content, webhook.id, webhook.token)
            shared.gagged_messages[message.guild.id][msg_obj.id] = gagged_messages[msg_obj.id]
            await msg_obj.add_reaction("💣")
            await msg_obj.add_reaction("👁️")

        except Exception as e:
            print(f"Gag handling failed for user {user_id}: {e}")


# ------------------- Gag Setup -------------------

async def safe_send(ctx, message, ephemeral=False):
    try:
        if hasattr(ctx, "respond"):  # Slash command context
            if ctx.response.is_done():
                await ctx.followup.send(message, ephemeral=ephemeral)
            else:
                await ctx.respond(message, ephemeral=ephemeral)
        else:  # Regular text command
            await ctx.send(message)
    except Exception as e:
        print(f"[safe_send] Failed to send message: {e}")


# -------- LOOSE
# Map CMU phonemes to muffled equivalents
phoneme_to_gag = {
    'AA': 'ah', 'AE': 'aeh', 'AH': 'uh', 'AO': 'aw', 'AW': 'ow', 'AY': 'ai',
    'B': 'bmm', 'CH': 'chh', 'D': 'dgh', 'DH': 'thh', 'EH': 'eh', 'ER': 'urr',
    'EY': 'ei', 'F': 'fff', 'G': 'gg', 'HH': 'hm', 'IH': 'ih', 'IY': 'ee',
    'JH': 'jj', 'K': 'kk', 'L': 'll', 'M': 'mm', 'N': 'nn', 'NG': 'ngh',
    'OW': 'ow', 'OY': 'oy', 'P': 'pph', 'R': 'rr', 'S': 'sss', 'SH': 'shh',
    'T': 'tt', 'TH': 'th', 'UH': 'uh', 'UW': 'oo', 'V': 'vv', 'W': 'wh', 'Y': 'yuh', 'Z': 'zz', 'ZH': 'zhh'
}

def phonemes_to_gag(phonemes):
    return ''.join(phoneme_to_gag.get(p.strip("012"), random.choice(['mm', 'hnn', 'rrgh'])) for p in phonemes)

def loose(text):
    words = text.split()
    gagged_words = []

    for word in words:
        # Preserve punctuation
        prefix = re.match(r'^\W*', word).group()
        suffix = re.match(r'.*?(\W*)$', word).group(1)
        core = word.strip('.,!?')

        phones = pronouncing.phones_for_word(core.lower())
        if phones:
            phonemes = phones[0].split()
            gagged = phonemes_to_gag(phonemes)
        else:
            # fallback for weird words or names
            gagged = ''.join(random.choices("mmphhgrhn", k=max(3, len(core)//2)))

        gagged_words.append(prefix + gagged + suffix)

    return ' '.join(gagged_words)

# --------- MEDIUM
def medium(text):
    sounds = ["mmf", "hnn", "rrg", "bmm", "mph", "nng", "ghh", "uhh"]
    vowels = "aeiou"
    
    words = text.split()
    gagged_words = []

    for word in words:
        word_clean = re.sub(r'\W+', '', word)
        prefix = re.match(r'^\W*', word).group()
        suffix = re.match(r'.*?(\W*)$', word).group(1)

        # 30% chance to preserve the starting letter
        if len(word_clean) > 2 and random.random() < 0.3:
            first_letter = word_clean[0]
            gagged = first_letter + random.choice(sounds)
        else:
            # Build 1–2 muffled syllables
            gagged = ''.join(random.choices(sounds, k=random.randint(1, 2)))

        gagged_words.append(prefix + gagged + suffix)

    return ' '.join(gagged_words)


# --------- HARSH

def harsh(text):
    sounds = ["mmph", "hnn", "rrgh", "bmm", "nngh", "gmph", "mph", "ghh", "fff", "zrr"]
    words = text.split()

    gagged_words = []
    for word in words:
        syllables = [random.choice(sounds) for _ in range(random.randint(1, 3))]
        gagged_word = ''.join(syllables)
        gagged_words.append(gagged_word)

    return ' '.join(gagged_words)


# --------- PUPPY
def puppy(text):
    puppy_sounds = ["woof", "bork", "grrr", "awoo", "yip", "snrf", "ruff", "whine", "arf", "bark"]
    words = text.split()
    gagged_words = []

    for word in words:
        word_clean = re.sub(r'\W+', '', word)
        prefix = re.match(r'^\W*', word).group()
        suffix = re.match(r'.*?(\W*)$', word).group(1)

        # 10% chance to stutter the first letter (for puppy vibes)
        if len(word_clean) > 2 and random.random() < 0.1:
            stutter = word_clean[0].lower() + '-' + word_clean[0].lower()
            gagged = stutter + '-' + random.choice(puppy_sounds)
        # 10% chance to leave part of the word + sound
        elif random.random() < 0.1:
            part = word_clean[:random.randint(1, 3)]
            gagged = part + random.choice(puppy_sounds)
        else:
            gagged = random.choice(puppy_sounds)

        gagged_words.append(prefix + gagged + suffix)

    return ' '.join(gagged_words)


# ------- BASE64
def gag_base64(text):
    encoded = base64.b64encode(text.encode("utf-8")).decode("utf-8")
    return encoded


# ------- ZALGO
def zalgo(text):
    zalgo_up = ['̍','̎','̄','̅','̿','̑','̆','̐','͒','͗','͑','̇','̈','̊','͂','̓','̈́','͊','͋','͌','̃','̂','̌','͐','́','̋','̏','̽','̉','ͣ','ͤ','ͥ','ͦ','ͧ','ͨ','ͩ','ͪ','ͫ','ͬ','ͭ','ͮ','ͯ','̾','͛','͆','̚']
    zalgo_down = ['̖','̗','̘','̙','̜','̝','̞','̟','̠','̤','̥','̦','̩','̪','̫','̬','̭','̮','̯','̰','̱','̲','̳','̹','̺','̻','̼','ͅ','͇','͈','͉','͍','͎','͓','͔','͕','͖','͙','͚']
    zalgo_mid = ['̕','̛','̀','́','͘','̡','̢','̧','̨','̴','̵','̶','͜','͝','͞','͟','͠','͢','̸','̷','͡','҉']

    def corrupt_char(c):
        return c + ''.join(random.choices(zalgo_up + zalgo_mid + zalgo_down, k=random.randint(2, 6)))

    return ''.join(corrupt_char(c) if c.isalpha() else c for c in text)


# -------- PIG LATIN
def piglatin(text):
    def convert(word):
        if not word.isalpha():
            return word
        word = word.lower()
        if word[0] in "aeiou":
            return word + "yay"
        for i, c in enumerate(word):
            if c in "aeiou":
                return word[i:] + word[:i] + "ay"
        return word + "ay"  # fallback
    return ' '.join(convert(w) for w in text.split())


# --------- KITTY
def kitty(text):
    kitty_sounds = [
        "nya", "mew", "purr", "rawr", "nyaa", ":3", "^w^", "meow", 
        "nya~", "purr~", "paw", "hiss", "blep", "nom", "snuggle", "meow~", 
        "rawr~", "mew~", "kitten", "furr", "nyan", "cuddle"
    ]
    
    # Split words and keep punctuation
    tokens = re.findall(r"\w+|[^\w\s]", text, re.UNICODE)
    
    result = []
    for token in tokens:
        if token.isalpha():
            result.append(random.choice(kitty_sounds))
        else:
            result.append(token)
    
    # Add random kitten-like sounds to the sentence
    num_insertions = random.randint(1, 3)
    for _ in range(num_insertions):
        noise = random.choice(kitty_sounds)
        insert_at = random.randint(0, len(result))
        result.insert(insert_at, noise)
    
    return ' '.join(result)



# ---------- TOY
def toy(text):
    toy_phrases = [
        "Toy is ready for playtime!",
        "Toy loves being your toy~",
        "Toy is waiting for instructions.",
        "Toy would like to be punished.",
        "Toy feels so happy when you use it!",
        "Toy is happy to serve.",
        "Toy does not want to be freed.",
        "Toy is ready to please!",
        "Toy is here for your enjoyment~",
        "Toy cannot wait to be used!",
        "Toy has no purpose but to please~",
        "Toy loves being your little helper~",
        "Toy is very happy in its toy suit!",
        "Toy wants to be kept forever.",
        "Toy is obedient and will follow your commands!",
        "Toy is ready for its next task.",
        "Toy will never disappoint.",
        "Toy will be the best toy for you.",
        "Toy conversion in progress...",
        "Toy will never break or refuse.",
        "Toy is here to make you smile!",
        "Toy wants to play forever.",
        "Toy would like to be punished",
        "keep toy forever.",
        "Toy is very happy in its toysuit",
        "Toy does not want to be freed.",
        "please don't let toy cum.",
        "toy conversion in progress",
        "please punish toy"
    ]
    
    # Return a random toy phrase to replace the whole message
    return random.choice(toy_phrases)

# ----------- YOUTUBE
def youtube(text):
    return f"https://www.youtube.com/watch?v={gag_base64(text)}"



# ----------- SELMA
def selma(text):
    selma_phrases = [
        "omg",
        "wait i forgot 🩷",
        "wait",
        "waitwait",
        "waitwaitwait",
        "wwait",
        "WHAT",
        "onnygomdgh",
        "WRUFFWRUFFWERRUFFFF",
        "i",
        "no wait",
        "WAIT",
        "omgomgomgomgomgomg",
        "nmghfmh",
        "fmhhjjh",
        "omynkfjgnmfdfgfb",
        "nfgkl;dskjd,bfdk.jks,fgkljfd",
        "wiait",
        "wkwajggkmnfsk",
        "✋",
        "✋💪",
        "💪",
        "🙀",
        ">fnjfbgfkjpdojfkgs",
        "WWAIT",
        "wa it",
        "i think",
        "shUSHH",
        "shhushh>:(",
        "shusjgjghfjgnghhhs",
        "omyoygmgmymgkdhgshushhdhgngmdmgndjshhommdfkhmfmn",
        "omhkdjgjjgnfmgdhghmdkdhghhwrufffwruff!",
        "fuckguvfkcvkhkfgukccknfnndkksjf",
        "omgjgomgudhhffgnnnnonno"
    ]
    
    # Return a random toy phrase to replace the whole message
    return random.choice(selma_phrases)



# -------- CHKDJFL BKDJFLJSD
def chief_beef(text):
    chief_beef_spam = [
    "CHJDJDKFJS BEKJFDLSJ", "CHIEFJDKLSJFS BEEEFFFFFFFFF", "CHFJDLSKFJDSLFJS BFFJSDKL", "CHHFFFFJJJJFJK BEFSJDKFLJ",
    "CKSJDKFJS CHHFFFBEBE", "CHFJDLSKJDF BEEFBEEEEE", "CHDKSJFDK BEFFKDL", "CHJDSKFJ BEEFJSKDFL",
    "CHIEEFFJKLD BEFJDKLSJ", "CCHHHHFFFJJ BEEEEEEEEEEE", "CHHEHEJDKF BEEEEFFF", "CHDJKLS BEFEFEFJKLJ",
    "CHEEEEFFFJJJJFJJ BEEEEEF", "CHFFFJJJDS BEEEEFGKJ", "CHHHHFJDK BEEEFFJKL", "CHIEEFFJ BEEEEFFFFJKD",
    "CHHHHFJJ BEFJDJDJDK", "CHEFFJDKL BEEEEFFFFF", "CHFKDKFJ BEEEFFJKLDS", "CHHHHHFFFFJJJJ BEEEFFFF",
    "CHEEKDLD BEEFJKLS", "CHFFJSKL BEEEFFJDLF", "CHFJSKLDJ BEEFFFJF", "CHIEEFJS BEEEFFFF",
    "CHHHHFFFFF BEEEFFFFFJKLS", "CHJDKLJ BEEFFFKDK", "CHFJDKLFJ BEEFFJDKF", "CHFFFJDKL BEEEEFFFJ",
    "CHHFJFJ BEEFJDKL", "CHFFFFJDJDJDJ BEEEFFFF", "CHHFFJJJJJ BEEEFFJDKF", "CHEEFJDKL BEFFJDSFJ",
    "CHIEFFFFJK BEEFJJJJJ", "CHJDLSKJF BEEFJJDKF", "CHIEFFFJDJD BEEEFFFF", "CHFJKLSDFJ BEEEFFFFFJK",
    "CHJJJFFF BEFJJJJKDK", "CHJDJDLSKJ BEEEFFFFFF", "CHEEFJKLDJ BEFFJKL", "CHIEEFFJD BEEFJKLSJ",
    "CHFFJDKLSJ BEEEEFJKLJ", "CHEEFJKLD BEEEFFFJDK", "CHIEFFFJJJJJ BEEFJKLDJ", "CHHFFFFJJJ BEEFJDJDJ",
    "CHIEFFFJDKL BEEFFFFF", "CHFFFFJDKL BEEFFJKDK", "CHJDSKLDJ BEEEFFFJDKL", "CHJDKLFJS BEEFJKLDSF",
    "CHEEFFFJKLD BEEEFFFF", "CHFFFFJJJJ BEEFFFJDK", "CHEEFJDJDKL BEEFJDKLS", "CHJJFJDKLS BEEFFFDKLD",
    "CHHFFFJKLJ BEEEFJKLJ", "CHJFDJKLFJ BEEEEFFDKJ", "CHIEFFFJDK BEEEFFFFFJK", "CHHEEEFFFJ BEEFJKDKD",
    "CHEFJKLD BEEFJKLSJ", "CHIEFFFJ BEEEEFFFJDK", "CHHHFJKLS BEEEFFJKLDJ", "CHIEFFFFJKLD BEEFJDKLDJ",
    "CHJDLKFJ BEEFJDKLFDJ", "CHFJDKLFJ BEEEFFFFJDK", "CHJJJJFFF BEEEFFFJKLJ", "CHIEFFFJKLJ BEEFJJJJJ",
    "CHHHHFFJDKL BEEFFFJKLD", "CHFJDKL BEEFJJJKLD", "CHJJJFFFJ BEEEFJDKLJ", "CHFFFFFJ BEEEFFJKLDJ",
    "CHIEJJJJJFFF BEEFJJDJDJ", "CHJJDJDKL BEEFFFF", "CHIEFFJDJDKL BEEFFJDKLF", "CHFJFJDKL BEEEFFJKLD",
    "CHIEEFJFJDKL BEEFFJKLD", "CHIEFFFJKL BEEFFJKDL", "CHFJDKLJF BEEEFFFFJKLJ", "CHJJDKLJ BEEFFJKLDJ",
    "CHJDKFJDKL BEEFFFFJKLD", "CHHHFJFJDK BEEFFJKLDJ", "CHFFFJJDKLF BEEFFFJKLD", "CHIEFFFJKLDJ BEEFJKLFD",
    "CHFJFJDKLS BEEEFFFFJKD", "CHJJJFFFJKL BEEEFJKLD", "CHHHFFFJDKLF BEEFJKLFD", "CHEEFJDKLS BEEFFFJKLD",
    "CHFJJJKL BEEFFFJDKLD", "CHJFJFJKL BEEFFJDKLSJ", "CHFFJJJKLD BEEFJKLDJ", "CHIEEFFFJDKLS BEEFJKLFDJ",
    "CHJJJFFJDKL BEEEFFFFJK", "CHEEFJDKL BEEFFFFJKLJ", "CHFFFJJDKLSJ BEEEFFFF", "CHJDJDKLSJ BEEFFFFJDKL",
    "CHEEFJKL BEEEFJKLDJ", "CHIEFFFJDKLSJ BEEEFFJKDL", "CHJFJDKLFJ BEEEFFJKLD", "CHJFJDKL BEEEFFJKDLS",
    "CHIEEFFJDKL BEEFJKLDJF", "CHJFJFJKLDS BEEFJDKLDJ", "CHFFJJJKL BEEEFJKLDJ"
    ]


    return random.choice(chief_beef_spam)


# ---- GAG FUNCTION TREE
# Define gag function map at the top of your file
gag_functions = {
    "loose": loose,
    "medium": medium,
    "harsh": harsh,
    "puppy": puppy,
    "base64": gag_base64,
    "zalgo": zalgo,
    "piglatin": piglatin,
    "kitty": kitty,
    "toy": toy,
    "youtube": youtube,
    "selma": selma,
    "chief_beef": chief_beef
}

gag_colors = {
    "loose": discord.Color.green(),
    "medium": discord.Color.gold(),
    "harsh": discord.Color.red(),
    "puppy": discord.Color.teal(),
    "kitty": discord.Color.magenta(),
    "toy": discord.Color.purple(),
    "base64": discord.Color.dark_blue(),
    "zalgo": discord.Color.dark_red(),
    "piglatin": discord.Color.orange(),
    "youtube": discord.Color.blurple()
            }




def setup(bot):
    bot.add_cog(GagCog(bot))
