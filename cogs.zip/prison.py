import discord
from discord.ext import commands
import shared
import time
import traceback

class PrisonCog(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        self.conn = shared.conn
        self.cursor = self.conn.cursor() if self.conn else None
        shared.enforce_prison_restrictions = self.enforce_prison_restrictions

    def cog_unload(self):
        print("[Prison] Unloading Prison Cog")
        shared.enforce_prison_restrictions = None

    async def enforce_prison_restrictions(self, message):
        try:
            shared.returnvar = False  # Default to False each time

            if not message.guild or message.author.bot:
                return

            guild_id = message.guild.id
            user_id = message.author.id
            channel_id = message.channel.id

            # ✅ Check if this cog is enabled for the guild
            if not shared.is_cog_enabled(guild_id, "prison_enabled"):
                return

            # ✅ Get per-guild data safely
            guild_prison_users = shared.prison_users.get(guild_id)


            if guild_prison_users is None or user_id not in guild_prison_users:
                return

            guild_temp_freed = shared.temporarily_freed.get(guild_id)
            if guild_temp_freed and user_id in guild_temp_freed and time.time() < guild_temp_freed[user_id]:
                return  # temporarily freed

            prison_channel_id = guild_prison_users[user_id]
            if channel_id != prison_channel_id:
                try:
                    await message.delete()
                    prison_channel = self.bot.get_channel(prison_channel_id)

                    # ⚡ PiShock integration
                    if user_id in shared.user_pishock_codes and shared.pishock_command:
                        shock_result = shared.pishock_command(user_id, op=0, intensity=80, duration=2)
                        if shock_result.get("Success"):
                            await message.channel.send(
                                f"⚡ Added 80% shock penalty for {message.author.display_name}!",
                                delete_after=10
                            )
                        else:
                            print(f"[PrisonCog] PiShock failed for {user_id}: {shock_result.get('Message')}")

                    await message.channel.send(
                        f"🔒 You're restricted to {prison_channel.mention if prison_channel else '#prison'}",
                        delete_after=10
                    )
                    shared.returnvar = True

                except Exception as e:
                    print(f"[PrisonCog] Prison restriction failed: {e}")
        except Exception as e:
            print(f"[PrisonCog] Prison enforcement crashed: {e}")
            traceback.print_exc()

def setup(bot):
    bot.add_cog(PrisonCog(bot))
