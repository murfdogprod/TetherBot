import discord
from discord.ext import commands
import requests
from shared import conn, check_auth, pishock_command
import shared
from muzzled import PISHOCK_USERNAME, PISHOCK_API_KEY
from shared import cog_enabled, with_config, unpack_config, with_config_cog

c = conn.cursor()

   # Set from env or shared config

class PiShockCog(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        shared.pishock_command = self.send_pishock_command  # Register in shared

    def cog_unload(self):
        shared.pishock_command = None  # Deregister on unload

    @commands.command(name='pishock')
    @cog_enabled("pishock_enabled")
    @with_config_cog
    async def pishock(self, ctx):
        """Set your PiShock friend share code: !>pishock <code>"""

        c = ctx.server_db.cursor()
        parts = ctx.message.content.strip().split()

        # If code is provided inline
        if len(parts) == 2:
            code = parts[1].strip()
            shared.user_pishock_codes[ctx.guild.id][ctx.author.id] = code
            c.execute(
                "INSERT OR REPLACE INTO pishock_users (user_id, code) VALUES (?, ?)",
                (ctx.author.id, code)
            )
            ctx.server_db.commit()
            return await ctx.send("✅ Your PiShock friend share code has been set.")

        # No code provided — initiate DM conversation
        try:
            dm_channel = await ctx.author.create_dm()
            await dm_channel.send("📩 Please reply with your PiShock friend share code.")

            def check(m):
                return m.author.id == ctx.author.id and isinstance(m.channel, discord.DMChannel)

            # Wait for reply (timeout after 60 seconds)
            reply = await self.bot.wait_for("message", check=check, timeout=60)

            code = reply.content.strip()
            shared.user_pishock_codes[ctx.guild.id][ctx.author.id] = code
            c.execute(
                "INSERT OR REPLACE INTO pishock_users (user_id, code) VALUES (?, ?)",
                (ctx.author.id, code)
            )
            ctx.server_db.commit()
            await dm_channel.send("✅ Your PiShock friend share code has been set successfully.")

            # Let them know in server too (optional)
            await ctx.send("✅ Code received in DM and saved.")

        except asyncio.TimeoutError:
            await ctx.author.send("⌛ Timed out waiting for a code. Please run `!>pishock` again to retry.")
            await ctx.send("⚠️ Timed out. No code received in DM.")
        except discord.Forbidden:
            await ctx.send("❌ I couldn't send you a DM. Please enable DMs from server members.")


    def send_pishock_command(self, guild_id: int, user_id: int, op: int, intensity: int, duration: int = 3):
        if not shared.is_cog_enabled(guild_id, "pishock_enabled"):
           return {"Success": False, "Message": "PiShock is disabled for this server."}

        if user_id not in shared.user_pishock_codes[guild_id]:
            return {"Success": False, "Message": "User does not have a PiShock friend share code."}

        share_code = shared.user_pishock_codes[guild_id][user_id]

        try:
            response = requests.post(
                "https://do.pishock.com/api/apioperate/",
                json={
                    "Username": PISHOCK_USERNAME,
                    "Apikey": PISHOCK_API_KEY,
                    "Code": share_code,
                    "Name": "TetherBot",
                    "Op": op,
                    "Duration": duration,
                    "Intensity": intensity
                }
            )
            if response.status_code != 200:
                return {"Success": False, "Message": f"HTTP Error: {response.status_code}"}

            if response.text.strip() == "Operation Attempted.":
                return {"Success": True, "Message": response.text.strip()}

            try:
                return response.json()
            except ValueError:
                return {"Success": False, "Message": f"Invalid response: {response.text}"}

        except Exception as e:
            print(f"Error sending PiShock command: {e}")
            return {"Success": False, "Message": str(e)}

    @commands.command(name='shock')
    @cog_enabled("pishock_enabled")
    @with_config_cog
    async def shock(self, ctx, user: discord.Member, intensity: int):
        if not await check_auth(ctx, user):
            await ctx.message.add_reaction("❌")
            return
        if not 1 <= intensity <= 100:
            return await ctx.send("Intensity must be between 1 and 100!")

        result = self.send_pishock_command(ctx.guild.id, user.id, op=0, intensity=intensity)

        if result.get("Success"):
            await ctx.send(f"⚡ Shocked {user.display_name} at {intensity}%!")
        else:
            await ctx.send(f"❌ Failed: {result.get('Message')}")

    @commands.command(name='vibrate')
    @cog_enabled("pishock_enabled")
    @with_config_cog
    async def vibrate(self, ctx, user: discord.Member, intensity: int):
        if not await check_auth(ctx, user):
            await ctx.message.add_reaction("❌")
            return
        if not 1 <= intensity <= 100:
            return await ctx.send("Intensity must be between 1 and 100!")

        result = self.send_pishock_command(ctx.guild.id, user.id, op=1, intensity=intensity)

        if result.get("Success"):
            await ctx.send(f"🔋 Vibrated {user.display_name} at {intensity}%!")
        else:
            await ctx.send(f"❌ Failed: {result.get('Message')}")

    @commands.command(name='beep')
    @cog_enabled("pishock_enabled")
    @with_config_cog
    async def beep(self, ctx, user: discord.Member, duration: int):
        if not await check_auth(ctx, user):
            await ctx.message.add_reaction("❌")
            return
        if not 1 <= duration <= 15:
            return await ctx.send("Duration must be between 1 and 15 seconds!")

        result = self.send_pishock_command(ctx.guild.id, user.id, op=2, intensity=1, duration=duration)

        if result.get("Success"):
            await ctx.send(f"🔔 Beeped {user.display_name} for {duration} seconds!")
        else:
            await ctx.send(f"❌ Failed: {result.get('Message')}")




def setup(bot):
    bot.add_cog(PiShockCog(bot))
